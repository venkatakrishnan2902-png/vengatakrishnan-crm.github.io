# Vengatakrishnan M Portfolio

Open `index.html` in a browser to preview the portfolio.

Before publishing:
1. Replace `YOUR_EMAIL@example.com` with your email.
2. Replace `YOUR_LINKEDIN_URL` with your LinkedIn profile URL.
3. The profile photo is in `assets/profile.png`.
